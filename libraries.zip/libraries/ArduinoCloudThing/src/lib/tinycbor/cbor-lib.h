#ifndef CBOR_LIB_H
#define CBOR_LIB_H

#include "src/cbor.h"

#endif